#include <stdio.h>
#include <stdlib.h>
#include "lista_rec.h"

struct No{
    int valor;
    No *prox;
};

int insereFinal(Lista *l, int it){ //recursiva
    if(l == NULL){
        l = (Lista*)malloc(sizeof(Lista));
        l->valor = it;
        l->prox = NULL;
        return 2;
    }
    if(l->prox == NULL){
        No *no = (Lista*)malloc(sizeof(Lista));
        l->prox = no;
        no->valor = it;
        no->prox = NULL;
        return 0;
    }
    return insereFinal(&(l->prox), it);
}
void mostra(Lista *l){
    if(l != NULL){
        No *no = (*l);
        printf("%d\n", no->valor);
        mostra(&(no->prox));
    }
}

int retornaUltimo(Lista *l, int *ultimo){
    if(l == NULL) return 2;
    if(l->prox == NULL){
        *ultimo = l->valor;
        return 0;
    }
    return retornaUltimo(&(l->prox), ultimo);
}

int retornaSoma(Lista *l){
    if(l == NULL) return -2;
    if(l->prox == NULL){
        return l->valor;
    }
    return (l->valor + retornaSoma(&(l->prox));
}

void mostraInversa(Lista *l){
    if(l==NULL) return 2;
    if(l->prox = NULL){
        printf("%d", l->valor);
    }
    else{
        mostraInversa(&(l->prox));
        printf("%d", l->valor);
    }
}

int removeOcorrencia (Lista *l, int ocorrencia);


int passaBinario(char *binario);
int incrementa (Lista *l, int numero); //recursiva
