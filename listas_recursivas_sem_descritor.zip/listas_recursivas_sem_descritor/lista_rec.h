#ifndef LISTA_REC_H_INCLUDED
#define LISTA_REC_H_INCLUDED

typedef struct No* Lista;

int insereFinal(Lista *l, int it);
void mostra(Lista *l);

int retornaUltimo(Lista *l, int *ultimo);

int retornaSoma(Lista *l);

void mostraInversa(Lista *l);

int removeOcorrencia (Lista *l, int ocorrencia);

int passaBinario(char *binario);
int incrementa (Lista *l, int numero); //recursiva

#endif // LISTA_REC_H_INCLUDED
