#include <stdio.h>
#include <stdlib.h>
#include "lista_rec.h"

int main()
{
    int op, retorno, num;
    Lista *l;

    do{
        printf("==== MENU ====\n\n");
        printf("1 - Inserir no final\n");
        printf("2 - Mostrar\n");
        printf("3 - Mostrar Inversa\n");
        printf("4 - Mostrar ultimo numero\n");
        printf("5 - Soma dos numeros\n");
        scanf("%d", &op);

        switch(op){
        case 1:
            printf("Digite o numero a ser inserido: ");
            scanf("%d", &num);

            retorno = insereFinal(l, num);

            if(retorno != 0){
                printf("Erro!\n\n");
            }
            break;
        case 2:
            mostra(l);
            break;
        case 3:
            mostraInversa(l);
            break;
        case 4:
            retorno = retornaUltimo(l, &num);

            if(retorno !=0){
                prinf("Erro!\n\n");
            }
            else{
                printf("Ultimo: %d\n\n", num);
            }
            break;
        case 5:
            retorno = retornaSoma(l);
            if(retorno==-2){
                printf("Erro!\n\n");
            }
            else{
                printf("Soma: %d\n\n", retorno);
            }
            break;
        case 6:
            break;
        default:
            printf("At� Logo!\n");
        }
    }while(op);

    return 0;
}
