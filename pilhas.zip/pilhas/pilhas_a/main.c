#include <stdio.h>
#include <stdlib.h>
#include "pilhas.h"

int main()
{
    Pilha *p = criar();
    int i;

    push(p, 11);
    push(p, 34);
    pop(p, &i);
    pop(p, &i);
    push(p, 23);
    push(p, 45);
    pop(p, &i);
    push(p, 121);
    push(p, 22);
    pop(p,&i);
    pop(p, &i);
    mostra(p);

    return 0;
}

