#include <stdio.h>
#include <stdlib.h>
#include "pilhas.h"

typedef struct no{
    int valor;
    struct no *prox;
}No;

typedef struct pilha{
    No *topo;
}Pilha;

Pilha *criar(){
    Pilha *p = (Pilha*)malloc(sizeof(Pilha));
    p->topo = NULL;
    return p;
}

int push(Pilha *p,int it){
    if(p==NULL) return 2;
    No *no = (No*)malloc(sizeof(No));
    no->valor = it;
    no->prox = p->topo;
    p->topo = no;
    return 0;
}
int pop(Pilha *p, int *it){
    if(p==NULL) return 2;
    if(pilhaVazia(p)==0) return 1;
    *it = p->topo->valor;
    No *no = p->topo;
    p->topo = p->topo->prox;
    free(no);
    return 0;
}
int acesso(Pilha *p, int *topo){
    if(p==NULL) return 2;
    if(pilhaVazia(p)==0) return 1;
    *topo = p->topo->valor;
    return 0;
}

void mostra(Pilha *p){
    int it;
    Pilha *aux = criar();
    printf("===\n");
    while(p->topo!=NULL){
        pop(p, &it);
        printf(" %d \n", it);
        push(aux, it);
    }
    printf("===\n");
    while(aux->topo!=NULL){
        pop(aux, &it);
        push(p, it);
    }
    return 0;
}
int pilhaVazia(Pilha *p){
    if(p==NULL)return 2;
    if(p->topo==NULL) return 0;
    return 1;
}
