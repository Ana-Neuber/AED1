#ifndef PILHAS_H_INCLUDED
#define PILHAS_H_INCLUDED

typedef struct pilha Pilha;

Pilha *criar();

int push(Pilha *p,int it);
int pop(Pilha *p, int* it);
void mostra(Pilha *p);
int acesso(Pilha *p, int *topo);
int pilhaVazia(Pilha *p);

#endif // PILHAS_H_INCLUDED
